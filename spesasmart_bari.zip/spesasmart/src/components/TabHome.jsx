import { STORES, SIGMA_PRODUCTS } from '../data.js'

const card = { background:'#fff', border:'0.5px solid rgba(0,0,0,0.1)', borderRadius:12, padding:16, marginBottom:12 }
const label = { fontSize:11, fontWeight:600, color:'#888', textTransform:'uppercase', letterSpacing:'.5px', marginBottom:8, display:'block' }

export default function TabHome({ raggio, setRaggio, setTab }) {
  const cats = ['carne','salumi','pesce','freschi','dolci','alimentari','bevande','surgelati','casalinghi']
  const counts = {}
  cats.forEach(c => { counts[c] = SIGMA_PRODUCTS.filter(p => p.cat === c).length })

  return (
    <div>
      {/* Hero */}
      <div style={{ background:'linear-gradient(135deg,#1D9E75,#085041)', borderRadius:14, padding:'20px 22px', marginBottom:16, color:'#fff' }}>
        <div style={{ fontSize:22, fontWeight:700, marginBottom:4 }}>Buona Pasqua con SpesaSmart</div>
        <div style={{ fontSize:13, opacity:.9 }}>Trova le migliori offerte Sigma Puglia — 26 Marzo al 4 Aprile 2026</div>
        <div style={{ display:'flex', gap:10, marginTop:14, flexWrap:'wrap' }}>
          {[
            { v:SIGMA_PRODUCTS.length, l:'Prodotti' },
            { v: STORES.length, l:'Punti vendita' },
            { v:'Pasqua', l:'Volantino' },
          ].map(x => (
            <div key={x.l} style={{ background:'rgba(255,255,255,.15)', borderRadius:8, padding:'8px 14px', minWidth:90 }}>
              <div style={{ fontSize:18, fontWeight:700 }}>{x.v}</div>
              <div style={{ fontSize:11, opacity:.85 }}>{x.l}</div>
            </div>
          ))}
        </div>
      </div>

      {/* Avviso disponibilità */}
      <div style={{ background:'#FAEEDA', border:'0.5px solid #EF9F27', borderRadius:10, padding:'10px 14px', fontSize:12, color:'#633806', marginBottom:16, display:'flex', gap:8 }}>
        <span>⚠</span>
        <span>Offerte salvo esaurimento scorte. La disponibilità dei prodotti non è garantita. Contatta direttamente il punto vendita per verificare. Prezzi soggetti a variazioni.</span>
      </div>

      {/* Raggio */}
      <div style={card}>
        <span style={label}>Impostazioni area</span>
        <div style={{ marginBottom:12 }}>
          <div style={{ fontSize:12, color:'#666', marginBottom:6 }}>Posizione di partenza</div>
          <input defaultValue="Centro di Bari, BA" style={{ width:'100%', padding:'8px 12px', border:'0.5px solid rgba(0,0,0,0.15)', borderRadius:8, fontSize:13 }} readOnly />
        </div>
        <div style={{ display:'flex', alignItems:'center', gap:12, background:'#F7F7F5', borderRadius:8, padding:'10px 12px' }}>
          <span style={{ fontSize:12, color:'#666', whiteSpace:'nowrap' }}>Raggio di ricerca:</span>
          <input type="range" min={1} max={20} value={raggio} onChange={e => setRaggio(Number(e.target.value))} style={{ flex:1 }} />
          <span style={{ fontSize:13, fontWeight:600, color:'#085041', minWidth:48 }}>{raggio} km</span>
        </div>
      </div>

      {/* Categorie */}
      <span style={label}>Esplora per categoria</span>
      <div style={{ display:'grid', gridTemplateColumns:'repeat(auto-fill,minmax(150px,1fr))', gap:8, marginBottom:16 }}>
        {cats.map(c => {
          const icons = { carne:'🥩', salumi:'🧀', pesce:'🐟', freschi:'🥛', dolci:'🍫', alimentari:'🍝', bevande:'🍺', surgelati:'🧊', casalinghi:'🧴' }
          return (
            <button key={c} onClick={() => {}} style={{ background:'#fff', border:'0.5px solid rgba(0,0,0,0.1)', borderRadius:10, padding:'12px 10px', cursor:'pointer', textAlign:'left', transition:'all .15s' }}
              onMouseEnter={e => e.currentTarget.style.borderColor='#1D9E75'}
              onMouseLeave={e => e.currentTarget.style.borderColor='rgba(0,0,0,0.1)'}>
              <div style={{ fontSize:22, marginBottom:4 }}>{icons[c]}</div>
              <div style={{ fontSize:12, fontWeight:500, textTransform:'capitalize' }}>{c}</div>
              <div style={{ fontSize:11, color:'#888' }}>{counts[c]} offerte</div>
            </button>
          )
        })}
      </div>

      {/* Punti vendita */}
      <span style={label}>Punti vendita Sigma — Bari</span>
      <div style={card}>
        {STORES.map((st, i) => (
          <div key={st.id} style={{ display:'flex', justifyContent:'space-between', alignItems:'center', padding:'9px 0', borderBottom: i < STORES.length-1 ? '0.5px solid rgba(0,0,0,0.07)' : 'none' }}>
            <div>
              <div style={{ fontSize:13, fontWeight:500 }}>{st.indirizzo}</div>
              <div style={{ fontSize:11, color:'#888' }}>{st.orari}</div>
            </div>
            <span style={{ background:'#E1F5EE', color:'#085041', borderRadius:6, fontSize:10, fontWeight:600, padding:'2px 7px' }}>Aperto</span>
          </div>
        ))}
        <div style={{ marginTop:10, padding:'8px 12px', background:'#E6F1FB', borderRadius:8, fontSize:11, color:'#0C447C' }}>
          + Capurso Via Bari 10/12 · Conversano Via Monopoli 102/104 · Conversano Via San Lorenzo 83 · Trani Via Giovanni Falcone 71
        </div>
      </div>

      {/* Bonus */}
      <div style={{ background:'#085041', borderRadius:12, padding:'14px 16px', color:'#fff', fontSize:13 }}>
        <div style={{ fontWeight:600, marginBottom:4 }}>🎁 Buono Sconto da €5</div>
        <div style={{ opacity:.9, fontSize:12 }}>Ogni €20 di spesa ricevi un buono sconto da €5 spendibile dal 6 all'8 Aprile 2026 con spesa minima di €30.</div>
      </div>
    </div>
  )
}
