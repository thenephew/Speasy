import { useState } from 'react'
import { STORES } from '../data.js'

const FUEL_PRICE = 1.78
const CONSUMI = { auto: 14, moto: 22 } // km/L

export default function TabPercorso({ transport, setTransport, cart, showToast }) {
  const cartHasItems = Object.keys(cart).length > 0
  const routeKm = 3.5
  const fuelL = transport === 'auto' ? (routeKm * 2) / CONSUMI.auto : transport === 'moto' ? (routeKm * 2) / CONSUMI.moto : 0
  const fuelCost = fuelL * FUEL_PRICE
  const risparmioOfferte = 14.10
  const risparmioNetto = risparmioOfferte - fuelCost

  const stops = [
    { num:1, nome:'Sigma — Via Melo da Bari, 165', dist:'1.2 km', tempo:{ piedi:'~15 min', mezzi:'~8 min', auto:'~5 min', moto:'~4 min' }, note:'Salumi, formaggi, prodotti Pasqua' },
    { num:2, nome:'Sigma — Via Re David, 94-98', dist:'0.8 km', tempo:{ piedi:'~10 min', mezzi:'~6 min', auto:'~4 min', moto:'~3 min' }, note:'Freschi, surgelati, bevande' },
    { num:3, nome:'Sigma — Via Giovanni Amendola, 13-15', dist:'1.5 km', tempo:{ piedi:'~18 min', mezzi:'~10 min', auto:'~6 min', moto:'~5 min' }, note:'Carne, dispensa, casa' },
  ]

  const modes = [
    { id:'piedi', icon:'🚶', label:'A piedi' },
    { id:'mezzi', icon:'🚌', label:'Mezzi' },
    { id:'auto', icon:'🚗', label:'Auto' },
    { id:'moto', icon:'🛵', label:'Moto' },
  ]

  return (
    <div>
      {/* Mezzo */}
      <div style={{ fontSize:12, fontWeight:600, color:'#888', textTransform:'uppercase', letterSpacing:'.4px', marginBottom:8 }}>Mezzo di trasporto</div>
      <div style={{ display:'grid', gridTemplateColumns:'repeat(4,1fr)', gap:8, marginBottom:16 }}>
        {modes.map(m => (
          <button key={m.id} onClick={() => setTransport(m.id)} style={{
            padding:'10px 6px', border:'0.5px solid', borderRadius:10, cursor:'pointer', textAlign:'center', transition:'all .15s', fontSize:12,
            background: transport===m.id ? '#E1F5EE' : '#fff',
            borderColor: transport===m.id ? '#1D9E75' : 'rgba(0,0,0,0.12)',
            color: transport===m.id ? '#085041' : '#444',
            fontWeight: transport===m.id ? 600 : 400,
          }}>
            <div style={{ fontSize:22, marginBottom:4 }}>{m.icon}</div>
            {m.label}
          </button>
        ))}
      </div>

      {/* Mappa placeholder */}
      <div style={{ background:'#F1EFE8', borderRadius:12, height:180, display:'flex', alignItems:'center', justifyContent:'center', marginBottom:16, border:'0.5px solid rgba(0,0,0,0.1)', flexDirection:'column', gap:6 }}>
        <div style={{ fontSize:28 }}>📍</div>
        <div style={{ fontSize:13, color:'#666', textAlign:'center' }}>Mappa interattiva<br/><span style={{ fontSize:11 }}>Google Maps in produzione</span></div>
        <a href={`https://www.google.com/maps/dir/Bari+BA/Sigma+Via+Melo+da+Bari+165/Sigma+Via+Re+David+94+Bari`} target="_blank" rel="noopener noreferrer"
          style={{ fontSize:12, color:'#185FA5', textDecoration:'underline' }}>Apri su Google Maps →</a>
      </div>

      {/* Tappe */}
      <div style={{ fontSize:12, fontWeight:600, color:'#888', textTransform:'uppercase', letterSpacing:'.4px', marginBottom:8 }}>Tappe ottimizzate</div>
      <div style={{ background:'#fff', border:'0.5px solid rgba(0,0,0,0.1)', borderRadius:12, padding:'0 16px', marginBottom:12 }}>
        {stops.map((stop, i) => (
          <div key={i} style={{ display:'flex', gap:12, padding:'12px 0', borderBottom: i < stops.length-1 ? '0.5px solid rgba(0,0,0,0.07)' : 'none' }}>
            <div style={{ width:26, height:26, borderRadius:'50%', background:'#1D9E75', color:'#fff', display:'flex', alignItems:'center', justifyContent:'center', fontSize:12, fontWeight:700, flexShrink:0, marginTop:1 }}>
              {stop.num}
            </div>
            <div style={{ flex:1 }}>
              <div style={{ fontSize:13, fontWeight:500 }}>{stop.nome}</div>
              <div style={{ fontSize:11, color:'#888', marginTop:2 }}>{stop.dist} · {stop.tempo[transport]}</div>
              <div style={{ fontSize:12, color:'#085041', marginTop:3 }}>{stop.note}</div>
            </div>
          </div>
        ))}
      </div>

      {/* Costi */}
      <div style={{ background:'#FAEEDA', border:'0.5px solid #EF9F27', borderRadius:12, padding:14, marginBottom:12 }}>
        <div style={{ fontSize:12, fontWeight:600, color:'#888', textTransform:'uppercase', letterSpacing:'.4px', marginBottom:10 }}>Calcolo costi reali</div>
        {[
          { l:'Percorso totale (andata+ritorno)', v:`${(routeKm*2).toFixed(1)} km` },
          { l:`Benzina (€${FUEL_PRICE}/L · ${transport === 'auto' ? CONSUMI.auto : transport === 'moto' ? CONSUMI.moto : '—'} km/L)`, v: fuelCost > 0 ? `€${fuelCost.toFixed(2).replace('.',',')}` : 'gratuito' },
          { l:'Risparmio lordo sulle offerte', v:`€${risparmioOfferte.toFixed(2)}` },
        ].map(r => (
          <div key={r.l} style={{ display:'flex', justifyContent:'space-between', fontSize:12, color:'#633806', marginBottom:5 }}>
            <span>{r.l}</span><span style={{ fontWeight:500 }}>{r.v}</span>
          </div>
        ))}
        <div style={{ display:'flex', justifyContent:'space-between', fontSize:14, fontWeight:700, color: risparmioNetto > 0 ? '#085041' : '#E24B4A', borderTop:'0.5px solid #EF9F27', paddingTop:8, marginTop:4 }}>
          <span>Risparmio netto reale</span>
          <span>€{risparmioNetto.toFixed(2).replace('.',',')}</span>
        </div>
      </div>

      <button onClick={() => { const list = stops.map((s,i) => `${i+1}. ${s.nome}`).join('\n'); const text = encodeURIComponent(`🗺 Percorso SpesaSmart Bari\n\n${list}\n\nMezzo: ${transport}\nTotale: ${routeKm*2} km`); window.open(`https://wa.me/?text=${text}`, '_blank') }}
        style={{ width:'100%', padding:11, background:'#1D9E75', color:'#fff', border:'none', borderRadius:10, fontSize:13, fontWeight:600, cursor:'pointer' }}>
        💬 Condividi percorso via WhatsApp
      </button>
    </div>
  )
}
