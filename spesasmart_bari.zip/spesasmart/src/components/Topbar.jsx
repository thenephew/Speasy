const s = {
  bar: { background:'#fff', borderBottom:'0.5px solid rgba(0,0,0,0.1)', padding:'10px 16px', display:'flex', alignItems:'center', justifyContent:'space-between', gap:12, position:'sticky', top:0, zIndex:100, flexWrap:'wrap' },
  logo: { fontSize:17, fontWeight:600, color:'#085041', display:'flex', alignItems:'center', gap:8, letterSpacing:'-0.3px' },
  logoIcon: { width:30, height:30, background:'#1D9E75', borderRadius:8, display:'flex', alignItems:'center', justifyContent:'center', color:'#fff', fontSize:15, fontWeight:700 },
  tabs: { display:'flex', gap:2, background:'#F1EFE8', borderRadius:10, padding:3, overflowX:'auto' },
  tab: (active) => ({ padding:'6px 11px', borderRadius:8, border:'none', background: active ? '#fff' : 'transparent', color: active ? '#1a1a1a' : '#666', fontSize:13, fontWeight: active ? 500 : 400, cursor:'pointer', whiteSpace:'nowrap', transition:'all .15s', boxShadow: active ? '0 1px 3px rgba(0,0,0,0.08)' : 'none' }),
  badge: { background:'#1D9E75', color:'#fff', borderRadius:10, fontSize:10, padding:'1px 5px', marginLeft:3 },
}

export default function Topbar({ tab, setTab, cartCount }) {
  const tabs = [
    { id:'home', label:'Home' },
    { id:'offerte', label:'Offerte' },
    { id:'carrello', label:'Carrello' },
    { id:'percorso', label:'Percorso' },
    { id:'admin', label:'Admin' },
  ]
  return (
    <div style={s.bar}>
      <div style={s.logo}>
        <div style={s.logoIcon}>S</div>
        SpesaSmart Bari
      </div>
      <div style={s.tabs}>
        {tabs.map(t => (
          <button key={t.id} style={s.tab(tab===t.id)} onClick={() => setTab(t.id)}>
            {t.label}
            {t.id === 'carrello' && cartCount > 0 && <span style={s.badge}>{cartCount}</span>}
          </button>
        ))}
      </div>
    </div>
  )
}
