import { useState } from 'react'

const LINKS = [
  { catena:'Sigma', url:'volantinofacile.it/sigma/bari', status:'ok' },
  { catena:'Lidl', url:'lidl.it/it/offerte', status:'ok' },
  { catena:'Eurospin', url:'eurospin.it/volantino', status:'ok' },
  { catena:'Conad', url:'volantino.conad.it/bari', status:'ok' },
  { catena:'Carrefour', url:'carrefour.it/volantino/bari', status:'warn' },
  { catena:'MD Discount', url:'mdsupermercati.it/volantino', status:'ok' },
]

export default function TabAdmin({ showToast }) {
  const [newLink, setNewLink] = useState('')
  const [links, setLinks] = useState(LINKS)
  const [chain, setChain] = useState('Sigma')
  const [validity, setValidity] = useState('26/03 – 04/04/2026')
  const [uploadStatus, setUploadStatus] = useState('')
  const [pdfText, setPdfText] = useState('')
  const [extracting, setExtracting] = useState(false)
  const [extracted, setExtracted] = useState([])

  const addLink = () => {
    if (!newLink.trim()) return
    setLinks(prev => [...prev, { catena: 'Nuovo', url: newLink.trim(), status:'ok' }])
    setNewLink('')
    showToast('Link aggiunto! Analisi volantino in corso...')
  }

  const extractWithAI = async () => {
    if (!pdfText.trim()) { showToast('Incolla prima il testo del volantino'); return }
    setExtracting(true)
    setExtracted([])
    try {
      const resp = await fetch('https://api.anthropic.com/v1/messages', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          model: 'claude-sonnet-4-20250514',
          max_tokens: 1000,
          messages: [{
            role: 'user',
            content: `Sei un estrattore esperto di dati da volantini di supermercati italiani. Analizza questo testo del volantino "${chain}" (validità: ${validity}). Per ogni prodotto trovato estrai: nome_normalizzato, prezzo_offerta (numero), categoria (tra: alimentari,freschi,carne,salumi,pesce,dolci,bevande,surgelati,casalinghi), unita. Rispondi SOLO con JSON array valido, senza markdown.\n\nTESTO:\n${pdfText}`
          }]
        })
      })
      const data = await resp.json()
      const raw = data.content.map(b => b.text || '').join('').replace(/```json|```/g,'').trim()
      const products = JSON.parse(raw)
      setExtracted(products)
      showToast(`✅ ${products.length} prodotti estratti!`)
    } catch(e) {
      showToast('Errore estrazione: ' + e.message)
    }
    setExtracting(false)
  }

  return (
    <div>
      {/* Header admin */}
      <div style={{ background:'#F1EFE8', borderRadius:10, padding:'12px 14px', marginBottom:16, borderLeft:'3px solid #888' }}>
        <div style={{ fontSize:13, fontWeight:600 }}>Pannello Amministratore</div>
        <div style={{ fontSize:11, color:'#666', marginTop:2 }}>Gestione volantini, punti vendita e link automatici</div>
      </div>

      {/* Carica PDF */}
      <div style={{ fontSize:11, fontWeight:600, color:'#888', textTransform:'uppercase', letterSpacing:'.4px', marginBottom:8 }}>Carica volantino PDF</div>
      <div style={{ background:'#fff', border:'0.5px solid rgba(0,0,0,0.1)', borderRadius:12, padding:16, marginBottom:16 }}>
        <div style={{ display:'grid', gridTemplateColumns:'1fr 1fr', gap:10, marginBottom:10 }}>
          <div>
            <label style={{ fontSize:11, color:'#888', display:'block', marginBottom:4 }}>Catena</label>
            <select value={chain} onChange={e => setChain(e.target.value)} style={{ width:'100%', padding:'8px 10px', border:'0.5px solid rgba(0,0,0,0.15)', borderRadius:8, fontSize:13 }}>
              {['Sigma','Lidl','Eurospin','Conad','Carrefour','MD Discount','Penny Market'].map(c => <option key={c}>{c}</option>)}
            </select>
          </div>
          <div>
            <label style={{ fontSize:11, color:'#888', display:'block', marginBottom:4 }}>Periodo validità</label>
            <input value={validity} onChange={e => setValidity(e.target.value)} style={{ width:'100%', padding:'8px 10px', border:'0.5px solid rgba(0,0,0,0.15)', borderRadius:8, fontSize:13 }} />
          </div>
        </div>

        <div onClick={() => showToast('Carica PDF: funzionalità backend in produzione')} style={{ border:'1.5px dashed rgba(0,0,0,0.15)', borderRadius:10, padding:'20px 0', textAlign:'center', cursor:'pointer', background:'#F7F7F5', marginBottom:10 }}>
          <div style={{ fontSize:28, marginBottom:6 }}>📄</div>
          <div style={{ fontSize:13, color:'#666' }}>Clicca per caricare un PDF volantino</div>
          <div style={{ fontSize:11, color:'#aaa', marginTop:2 }}>PDF, JPG, PNG</div>
        </div>

        <div>
          <label style={{ fontSize:11, color:'#888', display:'block', marginBottom:4 }}>Oppure incolla il testo estratto dal PDF</label>
          <textarea value={pdfText} onChange={e => setPdfText(e.target.value)} rows={5} placeholder="Incolla qui il testo del volantino..."
            style={{ width:'100%', padding:'8px 10px', border:'0.5px solid rgba(0,0,0,0.15)', borderRadius:8, fontSize:12, resize:'vertical' }} />
        </div>

        <button onClick={extractWithAI} disabled={extracting} style={{
          width:'100%', marginTop:8, padding:'10px 0', background: extracting ? '#9FE1CB' : '#1D9E75',
          color:'#fff', border:'none', borderRadius:8, fontSize:13, fontWeight:600, cursor: extracting ? 'not-allowed' : 'pointer'
        }}>
          {extracting ? '⏳ Estrazione AI in corso...' : '🤖 Estrai prodotti con AI'}
        </button>

        {extracted.length > 0 && (
          <div style={{ marginTop:12 }}>
            <div style={{ fontSize:12, color:'#085041', fontWeight:500, marginBottom:8 }}>✅ {extracted.length} prodotti estratti — verifica e salva</div>
            <div style={{ maxHeight:220, overflowY:'auto', border:'0.5px solid rgba(0,0,0,0.1)', borderRadius:8 }}>
              <table style={{ width:'100%', borderCollapse:'collapse', fontSize:11 }}>
                <thead><tr style={{ background:'#F7F7F5' }}>
                  {['Prodotto','Prezzo','Cat.','Unità'].map(h => <th key={h} style={{ padding:'6px 8px', textAlign:'left', fontWeight:600, color:'#888' }}>{h}</th>)}
                </tr></thead>
                <tbody>
                  {extracted.map((p,i) => (
                    <tr key={i} style={{ borderTop:'0.5px solid rgba(0,0,0,0.07)' }}>
                      <td style={{ padding:'6px 8px' }}>{p.nome_normalizzato}</td>
                      <td style={{ padding:'6px 8px', fontWeight:600, color:'#085041' }}>{p.prezzo_offerta ? `€${Number(p.prezzo_offerta).toFixed(2)}` : '—'}</td>
                      <td style={{ padding:'6px 8px', color:'#666' }}>{p.categoria}</td>
                      <td style={{ padding:'6px 8px', color:'#666' }}>{p.unita}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
            <button onClick={() => showToast(`${extracted.length} prodotti salvati nel database!`)}
              style={{ width:'100%', marginTop:8, padding:9, background:'#085041', color:'#fff', border:'none', borderRadius:8, fontSize:12, fontWeight:600, cursor:'pointer' }}>
              💾 Salva tutti nel database
            </button>
          </div>
        )}
      </div>

      {/* Link automatici */}
      <div style={{ fontSize:11, fontWeight:600, color:'#888', textTransform:'uppercase', letterSpacing:'.4px', marginBottom:8 }}>Link automatici volantini</div>
      <div style={{ background:'#fff', border:'0.5px solid rgba(0,0,0,0.1)', borderRadius:12, padding:'0 16px', marginBottom:16 }}>
        {links.map((l, i) => (
          <div key={i} style={{ display:'flex', alignItems:'center', justifyContent:'space-between', padding:'10px 0', borderBottom: i < links.length-1 ? '0.5px solid rgba(0,0,0,0.07)' : 'none' }}>
            <div>
              <div style={{ fontSize:13, fontWeight:500 }}>{l.catena}</div>
              <div style={{ fontSize:11, color:'#888' }}>{l.url}</div>
            </div>
            <div style={{ display:'flex', alignItems:'center', gap:8 }}>
              <span style={{ fontSize:10, fontWeight:600, background: l.status==='ok' ? '#E1F5EE' : '#FAEEDA', color: l.status==='ok' ? '#085041' : '#633806', borderRadius:6, padding:'2px 7px' }}>
                {l.status === 'ok' ? 'OK' : 'Warn'}
              </span>
              <div style={{ width:8, height:8, borderRadius:'50%', background: l.status==='ok' ? '#1D9E75' : '#BA7517' }} />
            </div>
          </div>
        ))}
        <div style={{ display:'flex', gap:8, padding:'12px 0' }}>
          <input value={newLink} onChange={e => setNewLink(e.target.value)} placeholder="Aggiungi nuovo link..." style={{ flex:1, padding:'7px 10px', border:'0.5px solid rgba(0,0,0,0.15)', borderRadius:8, fontSize:12 }} />
          <button onClick={addLink} style={{ padding:'7px 14px', background:'#1D9E75', color:'#fff', border:'none', borderRadius:8, fontSize:12, fontWeight:600, cursor:'pointer' }}>+ Aggiungi</button>
        </div>
      </div>

      {/* Punti vendita */}
      <div style={{ fontSize:11, fontWeight:600, color:'#888', textTransform:'uppercase', letterSpacing:'.4px', marginBottom:8 }}>Aggiungi punto vendita</div>
      <div style={{ background:'#fff', border:'0.5px solid rgba(0,0,0,0.1)', borderRadius:12, padding:16 }}>
        {[
          { label:'Nome punto vendita', placeholder:'es. Conad Via Roma, Bari' },
          { label:'Indirizzo completo', placeholder:'Via Roma 1, 70121 Bari' },
        ].map(f => (
          <div key={f.label} style={{ marginBottom:10 }}>
            <label style={{ fontSize:11, color:'#888', display:'block', marginBottom:4 }}>{f.label}</label>
            <input placeholder={f.placeholder} style={{ width:'100%', padding:'8px 10px', border:'0.5px solid rgba(0,0,0,0.15)', borderRadius:8, fontSize:13 }} />
          </div>
        ))}
        <div style={{ display:'grid', gridTemplateColumns:'1fr 1fr', gap:10, marginBottom:10 }}>
          <div>
            <label style={{ fontSize:11, color:'#888', display:'block', marginBottom:4 }}>Latitudine</label>
            <input placeholder="41.1171" style={{ width:'100%', padding:'8px 10px', border:'0.5px solid rgba(0,0,0,0.15)', borderRadius:8, fontSize:13 }} />
          </div>
          <div>
            <label style={{ fontSize:11, color:'#888', display:'block', marginBottom:4 }}>Longitudine</label>
            <input placeholder="16.8719" style={{ width:'100%', padding:'8px 10px', border:'0.5px solid rgba(0,0,0,0.15)', borderRadius:8, fontSize:13 }} />
          </div>
        </div>
        <button onClick={() => showToast('Punto vendita aggiunto con successo!')}
          style={{ width:'100%', padding:10, background:'#1D9E75', color:'#fff', border:'none', borderRadius:8, fontSize:13, fontWeight:600, cursor:'pointer' }}>
          Aggiungi punto vendita
        </button>
      </div>
    </div>
  )
}
