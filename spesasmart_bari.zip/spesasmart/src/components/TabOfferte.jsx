import { useState } from 'react'
import { SIGMA_PRODUCTS, CATEGORIES, CAT_COLORS } from '../data.js'

export default function TabOfferte({ addToCart }) {
  const [filter, setFilter] = useState('tutti')
  const [search, setSearch] = useState('')

  const visible = SIGMA_PRODUCTS.filter(p => {
    if (filter !== 'tutti' && p.cat !== filter) return false
    if (search && !p.nome.toLowerCase().includes(search.toLowerCase())) return false
    return true
  })

  return (
    <div>
      {/* Avviso */}
      <div style={{ background:'#FAEEDA', border:'0.5px solid #EF9F27', borderRadius:10, padding:'10px 14px', fontSize:12, color:'#633806', marginBottom:14, display:'flex', gap:8 }}>
        <span>⚠</span>
        <span>Disponibilità non garantita. Prodotti esauribili. I prezzi "Premiaty" richiedono la Carta Fedeltà Sigma. Verifica con il punto vendita.</span>
      </div>

      {/* Ricerca */}
      <input
        value={search} onChange={e => setSearch(e.target.value)}
        placeholder="🔍  Cerca prodotto…"
        style={{ width:'100%', padding:'10px 14px', border:'0.5px solid rgba(0,0,0,0.15)', borderRadius:10, fontSize:13, marginBottom:12, background:'#fff' }}
      />

      {/* Filtri */}
      <div style={{ display:'flex', gap:6, flexWrap:'wrap', marginBottom:16 }}>
        {CATEGORIES.map(c => (
          <button key={c.id} onClick={() => setFilter(c.id)} style={{
            padding:'5px 13px', borderRadius:16, border:'0.5px solid', fontSize:12, cursor:'pointer', transition:'all .15s',
            background: filter===c.id ? '#1D9E75' : '#fff',
            borderColor: filter===c.id ? '#1D9E75' : 'rgba(0,0,0,0.15)',
            color: filter===c.id ? '#fff' : '#444',
            fontWeight: filter===c.id ? 500 : 400,
          }}>{c.label}</button>
        ))}
      </div>

      <div style={{ fontSize:12, color:'#888', marginBottom:10 }}>{visible.length} prodotti</div>

      {/* Grid */}
      <div style={{ display:'grid', gridTemplateColumns:'repeat(auto-fill,minmax(200px,1fr))', gap:10 }}>
        {visible.map(p => {
          const cc = CAT_COLORS[p.cat] || CAT_COLORS.altro
          return (
            <div key={p.id} style={{ background:'#fff', border:'0.5px solid rgba(0,0,0,0.1)', borderRadius:10, padding:12, display:'flex', flexDirection:'column', gap:6 }}>
              <div style={{ display:'flex', justifyContent:'space-between', alignItems:'flex-start' }}>
                <span style={{ fontSize:10, fontWeight:600, background:cc.bg, color:cc.text, borderRadius:8, padding:'2px 7px' }}>{p.cat}</span>
                {p.premiaty && <span style={{ fontSize:9, background:'#EEEDFE', color:'#3C3489', borderRadius:6, padding:'2px 6px', fontWeight:600 }}>Premiaty</span>}
              </div>
              <div style={{ fontSize:13, fontWeight:500, lineHeight:1.3, flex:1 }}>{p.nome}</div>
              <div style={{ fontSize:11, color:'#888' }}>{p.unita}</div>
              <div style={{ display:'flex', alignItems:'baseline', gap:6 }}>
                {p.prezzo
                  ? <span style={{ fontSize:20, fontWeight:700, color:'#085041' }}>€{p.prezzo.toFixed(2).replace('.',',')}</span>
                  : <span style={{ fontSize:13, color:'#888' }}>Prezzo speciale</span>
                }
              </div>
              <div style={{ fontSize:11, color:'#666' }}>Sigma · p.{p.pag} volantino</div>
              <button onClick={() => addToCart(p)} style={{
                marginTop:4, padding:'7px 0', border:'0.5px solid #1D9E75', background:'#E1F5EE',
                color:'#085041', borderRadius:8, fontSize:12, fontWeight:500, cursor:'pointer', transition:'all .15s',
              }}
                onMouseEnter={e => { e.currentTarget.style.background='#1D9E75'; e.currentTarget.style.color='#fff' }}
                onMouseLeave={e => { e.currentTarget.style.background='#E1F5EE'; e.currentTarget.style.color='#085041' }}>
                + Aggiungi al carrello
              </button>
            </div>
          )
        })}
      </div>
      {visible.length === 0 && (
        <div style={{ textAlign:'center', padding:'40px 0', color:'#888' }}>Nessun prodotto trovato</div>
      )}
    </div>
  )
}
