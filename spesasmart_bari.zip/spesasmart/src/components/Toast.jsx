export default function Toast({ msg }) {
  return (
    <div style={{
      position:'fixed', bottom:20, left:'50%', transform:'translateX(-50%)',
      background:'#085041', color:'#fff', padding:'10px 18px', borderRadius:10,
      fontSize:13, fontWeight:500, zIndex:9999, boxShadow:'0 4px 16px rgba(0,0,0,0.15)',
      maxWidth:360, textAlign:'center', pointerEvents:'none',
    }}>
      {msg}
    </div>
  )
}
