import { SIGMA_PRODUCTS } from '../data.js'

const FUEL_PER_KM = 0.12 // ~1.78€/L, ~15km/L avg = 0.12€/km
const ROUTE_KM = 3.5

export default function TabCarrello({ cart, removeFromCart, changeQty, showToast, transport }) {
  const items = Object.entries(cart).map(([id, qty]) => ({
    product: SIGMA_PRODUCTS.find(p => p.id === Number(id)),
    qty
  })).filter(x => x.product)

  const subtotal = items.reduce((a, x) => a + (x.product.prezzo || 0) * x.qty, 0)
  const fuelCost = transport === 'auto' ? ROUTE_KM * FUEL_PER_KM * 2 : transport === 'moto' ? ROUTE_KM * 0.07 * 2 : 0
  const deliveryCost = subtotal >= 20 ? subtotal * 0.10 : 0
  const total = subtotal + fuelCost

  const shareWhatsApp = () => {
    if (items.length === 0) return
    const list = items.map(x => `• ${x.product.nome} ×${x.qty} — €${((x.product.prezzo||0)*x.qty).toFixed(2)}`).join('\n')
    const text = encodeURIComponent(`🛒 Lista SpesaSmart Bari\n\n${list}\n\nTotale: €${total.toFixed(2)}\n\nValidità offerte: 26 Mar – 4 Apr 2026\nSigma Puglia`)
    window.open(`https://wa.me/?text=${text}`, '_blank')
  }

  const downloadCSV = () => {
    const rows = [['Prodotto','Prezzo unitario','Quantità','Totale','Negozio']]
    items.forEach(x => rows.push([x.product.nome, x.product.prezzo||0, x.qty, ((x.product.prezzo||0)*x.qty).toFixed(2), x.product.negozio]))
    rows.push(['','','Subtotale', subtotal.toFixed(2),''])
    rows.push(['','','Carburante', fuelCost.toFixed(2),''])
    rows.push(['','','TOTALE NETTO', total.toFixed(2),''])
    const csv = rows.map(r => r.map(c => `"${c}"`).join(',')).join('\n')
    const a = document.createElement('a')
    a.href = 'data:text/csv;charset=utf-8,\uFEFF' + encodeURIComponent(csv)
    a.download = 'spesa_sigma_bari.csv'
    a.click()
  }

  if (items.length === 0) return (
    <div style={{ textAlign:'center', padding:'60px 20px' }}>
      <div style={{ fontSize:48, marginBottom:12 }}>🛒</div>
      <div style={{ fontSize:16, fontWeight:500, marginBottom:6 }}>Il tuo carrello è vuoto</div>
      <div style={{ fontSize:13, color:'#888' }}>Aggiungi prodotti dalla sezione Offerte</div>
    </div>
  )

  return (
    <div>
      <div style={{ background:'#FAEEDA', border:'0.5px solid #EF9F27', borderRadius:10, padding:'10px 14px', fontSize:12, color:'#633806', marginBottom:14, display:'flex', gap:8 }}>
        <span>⚠</span>
        <span>Disponibilità non garantita. Salvo esaurimento scorte. Verifica con il punto vendita prima di recarti.</span>
      </div>

      {/* Articoli */}
      <div style={{ background:'#fff', border:'0.5px solid rgba(0,0,0,0.1)', borderRadius:12, padding:'0 16px', marginBottom:12 }}>
        {items.map((x, i) => (
          <div key={x.product.id} style={{ display:'flex', alignItems:'center', gap:10, padding:'11px 0', borderBottom: i < items.length-1 ? '0.5px solid rgba(0,0,0,0.07)' : 'none' }}>
            <div style={{ flex:1 }}>
              <div style={{ fontSize:13, fontWeight:500 }}>{x.product.nome}</div>
              <div style={{ fontSize:11, color:'#888' }}>{x.product.negozio} · {x.product.unita}</div>
            </div>
            <div style={{ display:'flex', alignItems:'center', gap:6 }}>
              <button onClick={() => changeQty(x.product.id, -1)} style={{ width:26, height:26, border:'0.5px solid rgba(0,0,0,0.15)', borderRadius:6, background:'#F7F7F5', fontSize:16, cursor:'pointer' }}>−</button>
              <span style={{ fontSize:13, fontWeight:600, minWidth:16, textAlign:'center' }}>{x.qty}</span>
              <button onClick={() => changeQty(x.product.id, +1)} style={{ width:26, height:26, border:'0.5px solid rgba(0,0,0,0.15)', borderRadius:6, background:'#F7F7F5', fontSize:16, cursor:'pointer' }}>+</button>
            </div>
            <div style={{ fontSize:13, fontWeight:600, minWidth:52, textAlign:'right', color:'#085041' }}>
              €{((x.product.prezzo||0)*x.qty).toFixed(2).replace('.',',')}
            </div>
            <button onClick={() => removeFromCart(x.product.id)} style={{ border:'none', background:'none', color:'#E24B4A', fontSize:18, cursor:'pointer', padding:'0 2px' }}>×</button>
          </div>
        ))}
      </div>

      {/* Riepilogo */}
      <div style={{ background:'#E1F5EE', border:'0.5px solid #1D9E75', borderRadius:12, padding:16, marginBottom:12 }}>
        {[
          { l:'Subtotale prodotti', v:`€${subtotal.toFixed(2).replace('.',',')}` },
          { l:`Carburante stimato (${transport})`, v: fuelCost > 0 ? `€${fuelCost.toFixed(2).replace('.',',')}` : 'gratuito' },
        ].map(r => (
          <div key={r.l} style={{ display:'flex', justifyContent:'space-between', fontSize:13, marginBottom:6 }}>
            <span style={{ color:'#085041' }}>{r.l}</span><span>{r.v}</span>
          </div>
        ))}
        <div style={{ display:'flex', justifyContent:'space-between', fontSize:15, fontWeight:700, color:'#085041', borderTop:'0.5px solid #1D9E75', paddingTop:10, marginTop:4 }}>
          <span>Totale netto</span><span>€{total.toFixed(2).replace('.',',')}</span>
        </div>
      </div>

      {/* Consegna */}
      <div style={{ background:'#E6F1FB', border:'0.5px solid #85B7EB', borderRadius:12, padding:14, marginBottom:12 }}>
        <div style={{ fontSize:13, fontWeight:600, color:'#0C447C', marginBottom:4 }}>🚚 Consegna a domicilio</div>
        <div style={{ fontSize:12, color:'#185FA5', marginBottom:10 }}>
          Disponibile con supplemento del 10% sullo scontrino finale.
          {subtotal < 20 ? ' Spesa minima €20 non raggiunta.' : ` Costo consegna stimato: €${deliveryCost.toFixed(2)}`}
        </div>
        <button onClick={() => showToast('Richiesta consegna inviata! Riceverai conferma via email.')}
          style={{ width:'100%', padding:'9px 0', background: subtotal >= 20 ? '#185FA5' : '#B5D4F4', color:'#fff', border:'none', borderRadius:8, fontSize:13, fontWeight:500, cursor: subtotal >= 20 ? 'pointer' : 'not-allowed' }}>
          Richiedi consegna a domicilio
        </button>
      </div>

      {/* Pagamento */}
      <div style={{ background:'#fff', border:'0.5px solid rgba(0,0,0,0.1)', borderRadius:12, padding:14, marginBottom:12 }}>
        <div style={{ fontSize:12, fontWeight:600, color:'#888', textTransform:'uppercase', letterSpacing:'.4px', marginBottom:10 }}>Pagamento</div>
        <div style={{ display:'flex', gap:8 }}>
          <button onClick={() => showToast('PayPal: integrazione in arrivo!')}
            style={{ flex:1, padding:10, background:'#003087', color:'#fff', border:'none', borderRadius:8, fontSize:13, fontWeight:600, cursor:'pointer' }}>
            PayPal
          </button>
          <button onClick={() => showToast('Stripe: integrazione in arrivo!')}
            style={{ flex:1, padding:10, background:'#635BFF', color:'#fff', border:'none', borderRadius:8, fontSize:13, fontWeight:600, cursor:'pointer' }}>
            Stripe / Carta
          </button>
        </div>
      </div>

      {/* Condividi */}
      <div style={{ display:'flex', gap:8 }}>
        <button onClick={shareWhatsApp} style={{ flex:1, padding:10, border:'0.5px solid rgba(0,0,0,0.15)', background:'#fff', borderRadius:8, fontSize:12, fontWeight:500, cursor:'pointer', display:'flex', alignItems:'center', justifyContent:'center', gap:6 }}>
          💬 WhatsApp
        </button>
        <button onClick={downloadCSV} style={{ flex:1, padding:10, border:'0.5px solid rgba(0,0,0,0.15)', background:'#fff', borderRadius:8, fontSize:12, fontWeight:500, cursor:'pointer', display:'flex', alignItems:'center', justifyContent:'center', gap:6 }}>
          📄 Esporta CSV
        </button>
      </div>
    </div>
  )
}
