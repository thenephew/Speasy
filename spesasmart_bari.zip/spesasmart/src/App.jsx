import { useState } from 'react'
import Topbar from './components/Topbar.jsx'
import TabHome from './components/TabHome.jsx'
import TabOfferte from './components/TabOfferte.jsx'
import TabCarrello from './components/TabCarrello.jsx'
import TabPercorso from './components/TabPercorso.jsx'
import TabAdmin from './components/TabAdmin.jsx'
import Toast from './components/Toast.jsx'

export default function App() {
  const [tab, setTab] = useState('home')
  const [cart, setCart] = useState({}) // { id: qty }
  const [toast, setToast] = useState('')
  const [raggio, setRaggio] = useState(10)
  const [transport, setTransport] = useState('piedi')

  const showToast = (msg) => {
    setToast(msg)
    setTimeout(() => setToast(''), 2400)
  }

  const addToCart = (product) => {
    setCart(prev => ({ ...prev, [product.id]: (prev[product.id] || 0) + 1 }))
    showToast(`"${product.nome.substring(0,30)}" aggiunto al carrello!`)
  }

  const removeFromCart = (id) => {
    setCart(prev => { const n = {...prev}; delete n[id]; return n })
  }

  const changeQty = (id, delta) => {
    setCart(prev => {
      const newQty = (prev[id] || 0) + delta
      if (newQty <= 0) { const n = {...prev}; delete n[id]; return n }
      return { ...prev, [id]: newQty }
    })
  }

  const cartCount = Object.values(cart).reduce((a, b) => a + b, 0)

  const tabProps = { cart, addToCart, removeFromCart, changeQty, cartCount, showToast, raggio, setRaggio, transport, setTransport, setTab }

  return (
    <div style={{ minHeight: '100vh', display: 'flex', flexDirection: 'column' }}>
      <Topbar tab={tab} setTab={setTab} cartCount={cartCount} />
      <main style={{ flex: 1, maxWidth: 900, margin: '0 auto', width: '100%', padding: '16px 12px 40px' }}>
        {tab === 'home'     && <TabHome {...tabProps} />}
        {tab === 'offerte'  && <TabOfferte {...tabProps} />}
        {tab === 'carrello' && <TabCarrello {...tabProps} />}
        {tab === 'percorso' && <TabPercorso {...tabProps} />}
        {tab === 'admin'    && <TabAdmin {...tabProps} />}
      </main>
      {toast && <Toast msg={toast} />}
    </div>
  )
}
